console.log(process.argv);
console.log(process.argv.splice(2));